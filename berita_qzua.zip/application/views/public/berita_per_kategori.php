<?php
$param = 'Event';
echo'<a href="'.base_url().'kategori/'.$param.'">Klik</a>';
?>
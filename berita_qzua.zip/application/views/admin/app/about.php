<!-- <div class="page-breadcrumb breadcrumb" style="background-color:#8cb2ea;">
	<font color='black'>
		<h4></h4>
	</font>
</div> -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
  	Main bodies of QZUA members consist of Zhejiang companies in Australia and investors and traders from Zhejiang province, China.
  </div>
  <div class="card-body">
	<div class="table-responsive">
	QZUA is a non-governmental, non-religious and non-profitable association registered in Australian Queensland. Main bodies of members consist of Zhejiang companies in Australia and investors and traders from Zhejiang province, China. Zhejiang entrepreneurs are working industriously and successfully all the time in the overseas investment. As for in Australia, they invested A$760 million during the financial year of 2014-2015. Zhejiang is also one of the largest import provinces of Australian goods in China, e.g. milk powder, raw wool, wine, bio-health product, coking and thermal collect. Therefore, it is not hard to find that the potential of cooperation between Zhejiang and Queensland is booming and prospective.
	</div>
  </div>
</div>